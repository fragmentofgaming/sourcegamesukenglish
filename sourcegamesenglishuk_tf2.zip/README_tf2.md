I'd recommend backing up the files featured here beforehand.
Steps to install:
Step 1) Drop chat_english.txt and gameui_english.txt into \Team Fortress 2\hl2\resource\ (chat_english.txt is where most of the localisation is contained and gameui_english.txt is there to edit the loading screens)
Step 2) Drop serverbrowser_english.txt into \Team Fortress 2\platform\servers\ (This is the file that edits the community server browser)
Step 3) Drop tf_proto_obj_defs_english.txt and closecaption_english.txt into \Team Fortress 2\tf\resource\ (closecaption_english.txt edits the closed captions (obviously) in the developer commentary and tf_proto_obj_defs_english.txt edits the achievement/skin names)

Warning: These files may get overwritten in the next TF2 update (whenever that comes out), they might not but I'd still recommend reinstalling this mod anyway.
Have fun!