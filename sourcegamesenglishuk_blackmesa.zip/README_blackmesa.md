Put the sourcegamesukenglish_blackmesa folder into \Black Mesa\bms\custom\ and put the contents of the
serverbrowser folder into \Black Mesa\platform\servers\. Remember that each time Crowbar Collective
updates Black Mesa, you'll have to reinstall this mod. Have fun!