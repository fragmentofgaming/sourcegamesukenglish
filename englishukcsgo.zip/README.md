Place csgo_english_uk.txt into Counter-Strike: Global Offensive/csgo/resource.
Also place serverbrowser_english_uk.txt into Counter-Strike: Global Offensive/platform/servers.
Then add "-language english_uk" into your launch options.
Have fun!